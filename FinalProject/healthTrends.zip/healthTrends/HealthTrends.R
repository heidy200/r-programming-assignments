install.packages(c("devtools", "roxygen2"))
library(devtools)

create_package("healthTrends")

